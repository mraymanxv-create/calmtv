package com.calmtv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.media.tv.TvContract;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int KIND_APP = 0;
    private static final int KIND_TV = 1;

    private static class Entry {
        int kind = KIND_APP;
        String label;
        String pkg;
        Intent intent;
        Drawable icon;
        View view;
    }

    private static final int VISIBLE_RANGE = 4;
    private static final long ANIM_MS = 220;

    private final List<Entry> entries = new ArrayList<>();
    private FrameLayout carousel;
    private TextView wifiText;
    private ImageView wifiIcon;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCallback;
    private int selected = 0;
    private float step;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carousel = findViewById(R.id.carousel);
        wifiText = findViewById(R.id.wifi_text);
        wifiIcon = findViewById(R.id.wifi_icon);
        step = 170f * getResources().getDisplayMetrics().density;
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        buildCarousel();
        applyState(false);
        startNetworkWatch();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopNetworkWatch();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        selected = 0;
        applyState(true);
    }

    // ---------- التطبيقات ----------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        List<Entry> apps = new ArrayList<>();

        String[] categories = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : categories) {
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                Entry e = new Entry();
                e.pkg = pkg;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.icon = ri.loadIcon(pm);
                Intent li = new Intent(Intent.ACTION_MAIN);
                li.addCategory(cat);
                li.setClassName(pkg, ri.activityInfo.name);
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                e.intent = li;
                apps.add(e);
            }
        }

        final Collator collator = Collator.getInstance();
        Collections.sort(apps, new Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                return collator.compare(a.label, b.label);
            }
        });

        entries.clear();

        Entry tv = new Entry();
        tv.kind = KIND_TV;
        tv.pkg = "live_tv";
        tv.label = getString(R.string.live_tv);
        tv.icon = getDrawable(R.drawable.ic_tv);
        entries.add(tv);

        entries.addAll(apps);

        Entry settings = new Entry();
        settings.pkg = "settings";
        settings.label = getString(R.string.settings);
        settings.icon = getDrawable(R.drawable.ic_settings);
        Intent si = new Intent(Settings.ACTION_SETTINGS);
        si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        settings.intent = si;
        entries.add(settings);

        if (selected >= entries.size()) selected = entries.size() - 1;
        if (selected < 0) selected = 0;
    }

    private void buildCarousel() {
        carousel.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(this);
        for (Entry e : entries) {
            View v = inf.inflate(R.layout.item_app, carousel, false);
            ((ImageView) v.findViewById(R.id.icon)).setImageDrawable(e.icon);
            ((TextView) v.findViewById(R.id.label)).setText(e.label);
            v.setVisibility(View.GONE);
            e.view = v;
            carousel.addView(v);
        }
    }

    // ---------- الحركة ----------

    private void applyState(boolean animate) {
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            View v = e.view;
            if (v == null) continue;
            int d = i - selected;
            int ad = Math.abs(d);

            if (ad > VISIBLE_RANGE) {
                v.setVisibility(View.GONE);
                continue;
            }

            float tx = -d * step;
            float scale = d == 0 ? 1.3f : (ad == 1 ? 0.9f : 0.75f);
            float alpha = d == 0 ? 1f : (ad == 1 ? 0.65f : (ad == 2 ? 0.4f : 0.2f));
            float bgAlpha = d == 0 ? 1f : 0f;
            float labelAlpha = d == 0 ? 1f : 0f;

            View bg = v.findViewById(R.id.bg);
            View label = v.findViewById(R.id.label);

            boolean wasHidden = v.getVisibility() != View.VISIBLE;
            v.setVisibility(View.VISIBLE);

            if (!animate || wasHidden) {
                v.animate().cancel();
                v.setTranslationX(tx);
                v.setScaleX(scale);
                v.setScaleY(scale);
                v.setAlpha(alpha);
                bg.setAlpha(bgAlpha);
                label.setAlpha(labelAlpha);
            } else {
                v.animate().translationX(tx).scaleX(scale).scaleY(scale).alpha(alpha)
                        .setDuration(ANIM_MS).setInterpolator(new DecelerateInterpolator()).start();
                bg.animate().alpha(bgAlpha).setDuration(ANIM_MS).start();
                label.animate().alpha(labelAlpha).setDuration(ANIM_MS).start();
            }
        }
    }

    private void moveSelection(int delta) {
        int next = selected + delta;
        if (next < 0 || next >= entries.size()) return;
        selected = next;
        applyState(true);
    }

    // ---------- أزرار الريموت ----------

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                moveSelection(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                moveSelection(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                launch(entries.get(selected));
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_BACK:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override
    public void onBackPressed() {
    }

    // ---------- التشغيل ----------

    private void launch(Entry e) {
        if (e.kind == KIND_TV) {
            launchLiveTv();
            return;
        }
        try {
            startActivity(e.intent);
        } catch (Exception ignored) {
        }
    }

    private boolean tryStart(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private void launchLiveTv() {
        PackageManager pm = getPackageManager();

        // 1) تطبيقات القنوات المعروفة
        String[] known = {"com.google.android.tv", "com.android.tv"};
        for (String pkg : known) {
            Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (i == null) i = pm.getLaunchIntentForPackage(pkg);
            if (i != null && tryStart(i)) return;
        }

        // 2) البحث بين التطبيقات المثبتة عن تطبيق قنوات الشركة المصنّعة
        for (Entry e : entries) {
            if (e.kind != KIND_APP || e.pkg == null) continue;
            String p = e.pkg.toLowerCase(Locale.ROOT);
            if (p.contains("setting")) continue;
            if (p.contains("livetv") || p.contains("dtv") || p.contains("tvinput")
                    || p.contains("tvapp") || p.contains("tuner") || p.contains("tvplayer")) {
                if (tryStart(new Intent(e.intent))) return;
            }
        }

        // 3) فتح قائمة القنوات عبر نظام أندرويد
        Intent view = new Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI);
        if (view.resolveActivity(pm) != null && tryStart(view)) return;

        Toast.makeText(this, R.string.tv_not_found, Toast.LENGTH_LONG).show();
    }

    // ---------- حالة الشبكة ----------

    private void startNetworkWatch() {
        updateNetwork();
        if (cm == null) return;
        netCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateNetwork();
                    }
                });
            }

            @Override
            public void onLost(Network network) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateNetwork();
                    }
                });
            }

            @Override
            public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateNetwork();
                    }
                });
            }
        };
        try {
            cm.registerDefaultNetworkCallback(netCallback);
        } catch (Exception ignored) {
            netCallback = null;
        }
    }

    private void stopNetworkWatch() {
        if (cm != null && netCallback != null) {
            try {
                cm.unregisterNetworkCallback(netCallback);
            } catch (Exception ignored) {
            }
        }
        netCallback = null;
    }

    private void updateNetwork() {
        boolean connected = false;
        int textRes = R.string.offline;
        try {
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                connected = true;
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    textRes = R.string.wifi_on;
                } else if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                    textRes = R.string.eth_on;
                } else {
                    textRes = R.string.net_on;
                }
            }
        } catch (Exception ignored) {
        }
        wifiIcon.setImageResource(connected ? R.drawable.ic_wifi : R.drawable.ic_wifi_off);
        wifiText.setText(textRes);
    }
}
