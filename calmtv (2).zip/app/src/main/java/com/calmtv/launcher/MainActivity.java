package com.calmtv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.icu.text.SimpleDateFormat;
import android.icu.util.ULocale;
import android.media.tv.TvContract;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int KIND_APP = 0;
    private static final int KIND_TV = 1;
    private static final int RANGE = 4;
    private static final long ANIM_MS = 240;
    private static final String PREFS = "calmtv";
    private static final String KEY_PINS = "pins";

    private static class Entry {
        int kind = KIND_APP;
        String label;
        String pkg;
        Intent intent;
        Drawable icon;
        boolean pinned;
        View view;
    }

    private final List<Entry> entries = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final View[] topBg = new View[2];
    private FrameLayout carousel;
    private TextView subline;
    private ImageView wifiIcon;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCallback;
    private SharedPreferences prefs;

    private float u;
    private float step;
    private int selected = 0;
    private int mode = 0;      // 0 = الصف السفلي، 1 = الأيقونات العلوية
    private int topIndex = 0;  // 0 = الإعدادات، 1 = البحث

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateSubline();
            handler.postDelayed(this, 30000);
        }
    };

    private int px(float v) {
        return Math.round(v * u);
    }

    // ---------- دورة الحياة ----------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        u = getResources().getDisplayMetrics().widthPixels / 960f;
        step = 160f * u;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);

        carousel = findViewById(R.id.carousel);
        subline = findViewById(R.id.subline);
        wifiIcon = findViewById(R.id.wifi_icon);
        topBg[0] = findViewById(R.id.settings_bg);
        topBg[1] = findViewById(R.id.search_bg);
        applySizes();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        buildCarousel();
        applyState(false);
        applyTop();
        startNetworkWatch();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopNetworkWatch();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        selected = 0;
        mode = 0;
        applyTop();
        applyState(true);
    }

    // ---------- المقاسات (تتكيف مع أي شاشة) ----------

    private void applySizes() {
        FrameLayout.LayoutParams lp;

        View topLeft = findViewById(R.id.top_left);
        lp = (FrameLayout.LayoutParams) topLeft.getLayoutParams();
        lp.leftMargin = px(44);
        lp.topMargin = px(36);
        topLeft.setLayoutParams(lp);

        int[] btns = {R.id.btn_settings, R.id.btn_search};
        for (int id : btns) {
            View b = findViewById(id);
            LinearLayout.LayoutParams l = (LinearLayout.LayoutParams) b.getLayoutParams();
            l.width = px(60);
            l.height = px(60);
            l.bottomMargin = px(10);
            b.setLayoutParams(l);
        }
        int[] icons = {R.id.settings_icon, R.id.search_icon};
        for (int id : icons) {
            View ic = findViewById(id);
            ViewGroup.LayoutParams l = ic.getLayoutParams();
            l.width = px(30);
            l.height = px(30);
            ic.setLayoutParams(l);
        }

        lp = (FrameLayout.LayoutParams) wifiIcon.getLayoutParams();
        lp.width = px(36);
        lp.height = px(36);
        lp.rightMargin = px(48);
        lp.topMargin = px(44);
        wifiIcon.setLayoutParams(lp);

        View center = findViewById(R.id.center_col);
        lp = (FrameLayout.LayoutParams) center.getLayoutParams();
        lp.bottomMargin = px(120);
        center.setLayoutParams(lp);

        ((TextView) findViewById(R.id.day)).setTextSize(TypedValue.COMPLEX_UNIT_PX, 30f * u);
        ((TextView) findViewById(R.id.clock)).setTextSize(TypedValue.COMPLEX_UNIT_PX, 176f * u);
        subline.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24f * u);

        lp = (FrameLayout.LayoutParams) carousel.getLayoutParams();
        lp.height = px(190);
        lp.bottomMargin = px(30);
        carousel.setLayoutParams(lp);
    }

    // ---------- التحية والتاريخ ----------

    private void updateSubline() {
        try {
            Date now = new Date();
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            String greet;
            if (h >= 5 && h < 12) greet = getString(R.string.g_morning);
            else if (h >= 12 && h < 18) greet = getString(R.string.g_day);
            else greet = getString(R.string.g_evening);

            String greg = new SimpleDateFormat("d MMMM",
                    ULocale.forLanguageTag("ar-u-nu-latn")).format(now);
            String hijri = new SimpleDateFormat("d MMMM y",
                    ULocale.forLanguageTag("ar-u-ca-islamic-nu-latn")).format(now);
            subline.setText(greet + "  ·  " + greg + "  ·  " + hijri + " هـ");
        } catch (Exception e) {
            subline.setText("");
        }
    }

    // ---------- التطبيقات ----------

    private Set<String> getPins() {
        return new HashSet<>(prefs.getStringSet(KEY_PINS, new HashSet<String>()));
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> pins = getPins();
        Set<String> seen = new HashSet<>();
        List<Entry> apps = new ArrayList<>();

        String[] categories = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : categories) {
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                Entry e = new Entry();
                e.pkg = pkg;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.icon = ri.loadIcon(pm);
                e.pinned = pins.contains(pkg);
                Intent li = new Intent(Intent.ACTION_MAIN);
                li.addCategory(cat);
                li.setClassName(pkg, ri.activityInfo.name);
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                e.intent = li;
                apps.add(e);
            }
        }

        final Collator collator = Collator.getInstance();
        Collections.sort(apps, new Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
                return collator.compare(a.label, b.label);
            }
        });

        entries.clear();

        Entry tv = new Entry();
        tv.kind = KIND_TV;
        tv.pkg = "live_tv";
        tv.label = getString(R.string.live_tv);
        tv.icon = getDrawable(R.drawable.ic_tv);
        entries.add(tv);
        entries.addAll(apps);

        if (selected >= entries.size()) selected = entries.size() - 1;
        if (selected < 0) selected = 0;
    }

    private void buildCarousel() {
        carousel.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(this);
        for (Entry e : entries) {
            View v = inf.inflate(R.layout.item_app, carousel, false);

            FrameLayout.LayoutParams rootLp = new FrameLayout.LayoutParams(px(132), px(176));
            rootLp.gravity = Gravity.CENTER;
            v.setLayoutParams(rootLp);

            View glass = v.findViewById(R.id.glass);
            View bg = v.findViewById(R.id.bg);
            glass.getLayoutParams().height = px(132);
            bg.getLayoutParams().height = px(132);

            ImageView icon = v.findViewById(R.id.icon);
            FrameLayout.LayoutParams ilp = (FrameLayout.LayoutParams) icon.getLayoutParams();
            ilp.width = px(68);
            ilp.height = px(68);
            ilp.topMargin = px(32);
            icon.setLayoutParams(ilp);
            icon.setImageDrawable(e.icon);

            TextView label = v.findViewById(R.id.label);
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 19f * u);
            label.setText(e.pinned ? "★ " + e.label : e.label);

            v.setPivotX(px(66));
            v.setPivotY(px(66));
            v.setVisibility(View.GONE);
            e.view = v;
            carousel.addView(v);
        }
    }

    // ---------- الحركة ----------

    private void applyState(boolean animate) {
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            View v = e.view;
            if (v == null) continue;
            int d = i - selected;
            int ad = Math.abs(d);

            if (ad > RANGE) {
                v.animate().cancel();
                v.setVisibility(View.GONE);
                continue;
            }

            float tx = -d * step;
            float scale = d == 0 ? 1.18f : 0.94f;
            float alpha;
            if (d == 0) alpha = 1f;
            else if (ad == 1) alpha = 0.9f;
            else if (ad == 2) alpha = 0.7f;
            else if (ad == 3) alpha = 0.5f;
            else alpha = 0.3f;
            float bgAlpha = d == 0 ? (mode == 0 ? 1f : 0.35f) : 0f;
            float labelAlpha = d == 0 ? 1f : 0f;

            View bg = v.findViewById(R.id.bg);
            View label = v.findViewById(R.id.label);

            boolean wasHidden = v.getVisibility() != View.VISIBLE;
            v.setVisibility(View.VISIBLE);

            if (!animate || wasHidden) {
                v.animate().cancel();
                v.setTranslationX(tx);
                v.setScaleX(scale);
                v.setScaleY(scale);
                v.setAlpha(alpha);
                bg.setAlpha(bgAlpha);
                label.setAlpha(labelAlpha);
            } else {
                v.animate().translationX(tx).scaleX(scale).scaleY(scale).alpha(alpha)
                        .setDuration(ANIM_MS).setInterpolator(new DecelerateInterpolator()).start();
                bg.animate().alpha(bgAlpha).setDuration(ANIM_MS).start();
                label.animate().alpha(labelAlpha).setDuration(ANIM_MS).start();
            }
        }
    }

    private void applyTop() {
        for (int i = 0; i < topBg.length; i++) {
            float a = (mode == 1 && i == topIndex) ? 1f : 0f;
            topBg[i].animate().alpha(a).setDuration(160).start();
        }
    }

    private void moveSelection(int delta) {
        int next = selected + delta;
        if (next < 0 || next >= entries.size()) return;
        selected = next;
        applyState(true);
    }

    private void setMode(int m, int idx) {
        mode = m;
        topIndex = idx;
        applyTop();
        applyState(true);
    }

    // ---------- أزرار الريموت ----------

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (mode == 0) moveSelection(1);
                else setMode(0, topIndex);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (mode == 0) moveSelection(-1);
                else setMode(0, topIndex);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (mode == 0) setMode(1, 0);
                else if (topIndex > 0) setMode(1, topIndex - 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (mode == 1) {
                    if (topIndex < 1) setMode(1, topIndex + 1);
                    else setMode(0, topIndex);
                }
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (event.getRepeatCount() == 0) {
                    if (mode == 1) {
                        if (topIndex == 0) openSettings();
                        else openSearch();
                    } else {
                        event.startTracking();
                    }
                }
                return true;
            case KeyEvent.KEYCODE_BACK:
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (mode == 0 && isCenterKey(keyCode)) {
            togglePin(entries.get(selected));
            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (mode == 0 && isCenterKey(keyCode)) {
            if (event.isTracking() && !event.isCanceled()) {
                launch(entries.get(selected));
            }
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private boolean isCenterKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
                || keyCode == KeyEvent.KEYCODE_BUTTON_A;
    }

    @Override
    public void onBackPressed() {
    }

    // ---------- التثبيت ----------

    private void togglePin(Entry e) {
        if (e.kind != KIND_APP) return;
        Set<String> pins = getPins();
        boolean nowPinned;
        if (pins.contains(e.pkg)) {
            pins.remove(e.pkg);
            nowPinned = false;
        } else {
            pins.add(e.pkg);
            nowPinned = true;
        }
        prefs.edit().putStringSet(KEY_PINS, pins).apply();

        String pkg = e.pkg;
        String name = e.label;
        loadApps();
        for (int i = 0; i < entries.size(); i++) {
            if (pkg.equals(entries.get(i).pkg)) {
                selected = i;
                break;
            }
        }
        buildCarousel();
        applyState(false);

        if (nowPinned) {
            Toast.makeText(this, getString(R.string.pinned, name), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.unpinned, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- التشغيل ----------

    private boolean tryStart(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private void launch(Entry e) {
        if (e.kind == KIND_TV) {
            launchLiveTv();
            return;
        }
        tryStart(new Intent(e.intent));
    }

    private void openSettings() {
        tryStart(new Intent(Settings.ACTION_SETTINGS));
    }

    private void openSearch() {
        if (tryStart(new Intent("android.search.action.GLOBAL_SEARCH"))) return;
        if (tryStart(new Intent(Intent.ACTION_VOICE_COMMAND))) return;
        if (tryStart(new Intent(Intent.ACTION_ASSIST))) return;
        Toast.makeText(this, R.string.search_not_found, Toast.LENGTH_LONG).show();
    }

    private void launchLiveTv() {
        PackageManager pm = getPackageManager();

        String[] known = {"com.google.android.tv", "com.android.tv"};
        for (String pkg : known) {
            Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (i == null) i = pm.getLaunchIntentForPackage(pkg);
            if (i != null && tryStart(i)) return;
        }

        for (Entry e : entries) {
            if (e.kind != KIND_APP || e.pkg == null) continue;
            String p = e.pkg.toLowerCase(Locale.ROOT);
            if (p.contains("setting")) continue;
            if (p.contains("livetv") || p.contains("dtv") || p.contains("tvinput")
                    || p.contains("tvapp") || p.contains("tuner") || p.contains("tvplayer")) {
                if (tryStart(new Intent(e.intent))) return;
            }
        }

        Intent view = new Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI);
        if (view.resolveActivity(pm) != null && tryStart(view)) return;

        Toast.makeText(this, R.string.tv_not_found, Toast.LENGTH_LONG).show();
    }

    // ---------- حالة الشبكة ----------

    private void startNetworkWatch() {
        updateNetwork();
        if (cm == null) return;
        netCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                refreshNetworkOnUi();
            }

            @Override
            public void onLost(Network network) {
                refreshNetworkOnUi();
            }

            @Override
            public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                refreshNetworkOnUi();
            }
        };
        try {
            cm.registerDefaultNetworkCallback(netCallback);
        } catch (Exception ignored) {
            netCallback = null;
        }
    }

    private void refreshNetworkOnUi() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateNetwork();
            }
        });
    }

    private void stopNetworkWatch() {
        if (cm != null && netCallback != null) {
            try {
                cm.unregisterNetworkCallback(netCallback);
            } catch (Exception ignored) {
            }
        }
        netCallback = null;
    }

    private void updateNetwork() {
        boolean connected = false;
        try {
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            connected = c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception ignored) {
        }
        wifiIcon.setImageResource(connected ? R.drawable.ic_wifi : R.drawable.ic_wifi_off);
    }
}
